//
//  jiyiEeuialipayAppModule.h
//  Pods
//

#import <Foundation/Foundation.h>
#import <WeexSDK/WeexSDK.h>

@interface jiyiEeuialipayAppModule : NSObject <WXModuleProtocol>


@end
