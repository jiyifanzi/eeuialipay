//
//  jiyiEeuialipayEntry.h
//  Pods
//

#import <Foundation/Foundation.h>

@interface jiyiEeuialipayEntry : NSObject

@end
