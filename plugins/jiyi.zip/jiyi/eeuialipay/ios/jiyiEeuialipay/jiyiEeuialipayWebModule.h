//
//  jiyiEeuialipayWebModule.h
//  Pods
//

#import <Foundation/Foundation.h>
#import <WeexSDK/WeexSDK.h>

@interface jiyiEeuialipayWebModule : NSObject

@end
